var ERROR = "ERROR";

// Create or Open Database.
var db = window.openDatabase("FGW", "1.0", "FGW", 20000);

// To detect whether users use mobile phones horizontally or vertically.
$(window).on("orientationchange", onOrientationChange);

// Display messages in the console.
function log(message, type = "INFO") {
  console.log(`${new Date()} [${type}] ${message}`);
}

function onOrientationChange(e) {
  if (e.orientation == "portrait") {
    log("Portrait.");
  } else {
    log("Landscape.");
  }
}

// To detect whether users open applications on mobile phones or browsers.
if (navigator.userAgent.match(/(iPhone|iPod|iPad|Android|BlackBerry)/)) {
  $(document).on("deviceready", onDeviceReady);
} else {
  $(document).on("ready", onDeviceReady);
}

// Display errors when executing SQL queries.
function transactionError(tx, error) {
  log(`SQL Error ${error.code}. Message: ${error.message}.`, ERROR);
}

// Run this function after starting the application.
function onDeviceReady() {
  log(`Device is ready.`);
  prepareDatabase(db);

  db.transaction(function (tx) {
    // Create table ACCOUNT.
    var query = `CREATE TABLE IF NOT EXISTS Property (Id INTEGER PRIMARY KEY AUTOINCREMENT,
                                                         propertyName TEXT NOT NULL UNIQUE,
                                                         propertyAddress TEXT NOT NULL UNIQUE,
                                                         propertyType TEXT NOT NULL UNIQUE,
                                                         bedroom TEXT NOT NULL UNIQUE,
                                                         date TEXT NOT NULL UNIQUE,
                                                         monthlyRentPrice TEXT NOT NULL,
                                                         furnitureType TEXT NULL,
                                                         notes TEXT NULL,
                                                         reporterName TEXT NOT NULL)`;
    tx.executeSql(
      query,
      [],
      function (tx, result) {
        log(`Create table 'Property' successfully.`);
      },
      transactionError
    );

    // Create table COMMENT.
    var query = `CREATE TABLE IF NOT EXISTS Comment (Id INTEGER PRIMARY KEY AUTOINCREMENT,
                                                         Comment TEXT NOT NULL,
                                                         Datetime DATE NOT NULL,
                                                         AccountId INTEGER NOT NULL,
                                                         FOREIGN KEY (AccountId) REFERENCES Account(Id))`;
    tx.executeSql(
      query,
      [],
      function (tx, result) {
        log(`Create table 'Comment' successfully.`);
      },
      transactionError
    );
  });
}

// Submit a form to add new property
$(document).on("submit", "#page-create #frm-register", confirmProperty);
$(document).on("submit", "#page-create #frm-confirm", registerProperty);

function confirmProperty(e) {
  e.preventDefault();

  var propertyName = $("#page-create #frm-register #propertyName").val();
  var propertyAddress = $("#page-create #frm-register #propertyName").val();
  var propertyType = $("#page-create #frm-register #propertyType").val();
  var bedroom = $("#page-create #frm-register #bedroom").val();
  var date = $("#page-create #frm-register #date").val();
  var monthlyRentPrice = $(
    "#page-create #frm-register #monthlyRentPrice"
  ).val();
  var furnitureType = $("#page-create #frm-register #furnitureType").val();
  var notes = $("#page-create #frm-register #notes").val();
  var reporterName = $("#page-create #frm-register #reporterName").val();

  $("#page-create #frm-confirm #propertyName").val(propertyName);
  $("#page-create #frm-confirm #propertyAddress").val(propertyAddress);
  $("#page-create #frm-confirm #propertyType").val(propertyType);
  $("#page-create #frm-confirm #bedroom").val(bedroom);
  $("#page-create #frm-confirm #date").val(date);
  $("#page-create #frm-confirm #monthlyRentPrice").val(monthlyRentPrice);
  $("#page-create #frm-confirm #furnitureType").val(furnitureType);
  $("#page-create #frm-confirm #notes").val(notes);
  $("#page-create #frm-confirm #reporterName").val(reporterName);

  $("#page-create #frm-confirm").popup("open");
}

function registerProperty(e) {
  e.preventDefault();

  var propertyName = $("#page-create #frm-register #propertyName").val();
  var propertyAddress = $("#page-create #frm-register #propertyAddress").val();
  var propertyType = $("#page-create #frm-register #propertyType").val();
  var bedroom = $("#page-create #frm-register #bedroom").val();
  var date = $("#page-create #frm-register #date").val();
  var monthlyRentPrice = $(
    "#page-create #frm-register #monthlyRentPrice"
  ).val();
  var furnitureType = $("#page-create #frm-register #furnitureType").val();
  var notes = $("#page-create #frm-register #notes").val();
  var reporterName = $("#page-create #frm-register #reporterName").val();

  db.transaction(function (tx) {
    var query =
      "INSERT INTO Property (propertyName, propertyAddress, propertyType, bedroom, date, monthlyRentPrice, furnitureType, notes, reporterName) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    tx.executeSql(
      query,
      [
        propertyName,
        propertyAddress,
        propertyType,
        bedroom,
        date,
        monthlyRentPrice,
        furnitureType,
        notes,
        reporterName,
      ],
      transactionSuccess,
      transactionError
    );

    function transactionSuccess(tx, result) {
      log(`Add a new property '${propertyName}' successfully.`);

      // Reset the form.
      $("#frm-register").trigger("reset");
      $("#page-create #error").empty();
      $("#page-create #frm-confirm").popup("close");
    }
  });
}

// Display Account List.
$(document).on("pagebeforeshow", "#page-list", showList);

function showList() {
  db.transaction(function (tx) {
    var query =
      "SELECT Id, propertyName, propertyAddress, propertyType, bedroom, date, monthlyRentPrice, furnitureType, notes, reporterName FROM Property";
    tx.executeSql(query, [], transactionSuccess, transactionError);

    function transactionSuccess(tx, result) {
      log(`Get list of accounts successfully.`);

      // Prepare the list of accounts.
      var listProperty = `<ul id='list-account' data-role='listview' data-filter='true' data-filter-placeholder='Search properties...'
                                                     data-corners='false' class='ui-nodisc-icon ui-alt-icon'>`;
      for (let property of result.rows) {
        listProperty += `<li><a data-details='{"Id" : ${property.Id}}'>
                                    <img src='img/boyscout_logo.jpg'>
                                    <h3>Property: ${property.propertyName}</h3>
                                    <p>ID: ${property.Id}</p>
                                </a></li>`;
      }
      listProperty += `</ul>`;

      // Add list to UI.
      $("#page-list #list-account")
        .empty()
        .append(listProperty)
        .listview("refresh")
        .trigger("create");

      log(`Show list of properties successfully.`);
    }
  });
}

// Save Account Id.
$(document).on("vclick", "#list-account li a", function (e) {
  e.preventDefault();

  var id = $(this).data("details").Id;
  localStorage.setItem("currentPropertyId", id);

  $.mobile.navigate("#page-detail", { transition: "none" });
});

// Show Account Details.
$(document).on("pagebeforeshow", "#page-detail", showDetail);

function showDetail() {
  var id = localStorage.getItem("currentPropertyId");

  db.transaction(function (tx) {
    var query = "SELECT * FROM Property WHERE Id = ?";
    tx.executeSql(query, [id], transactionSuccess, transactionError);

    function transactionSuccess(tx, result) {
      var errorMessage = "Property not found.";
      var propertyName = errorMessage;
      var propertyAddress = errorMessage;
      var propertyType = errorMessage;
      var bedroom = errorMessage;
      var date = errorMessage;
      var monthlyRentPrice = errorMessage;
      var furnitureType = errorMessage;
      var notes = errorMessage;
      var reporterName = errorMessage;

      if (result.rows[0] != null) {
        log(`Get details of property '${id}' successfully.`);

        propertyName = result.rows[0].propertyName;
        propertyAddress = result.rows[0].propertyAddress;
        propertyType = result.rows[0].propertyType;
        bedroom = result.rows[0].bedroom;
        date = result.rows[0].date;
        monthlyRentPrice = result.rows[0].monthlyRentPrice;
        furnitureType = result.rows[0].furnitureType;
        notes = result.rows[0].notes;
        reporterName = result.rows[0].reporterName;
      } else {
        log(errorMessage, ERROR);

        $("#page-detail #btn-update").addClass("ui-disabled");
        $("#page-detail #btn-delete-confirm").addClass("ui-disabled");
      }

      $("#page-detail #id").val(id);
      $("#page-detail #propertyName").val(propertyName);
      $("#page-detail #propertyAddress").val(propertyAddress);
      $("#page-detail #propertyType").val(propertyType);
      $("#page-detail #bedroom").val(bedroom);
      $("#page-detail #date").val(date);
      $("#page-detail #monthlyRentPrice").val(monthlyRentPrice);
      $("#page-detail #furnitureType").val(furnitureType);
      $("#page-detail #notes").val(notes);
      $("#page-detail #reporterName").val(reporterName);

      showComment();
    }
  });
}

// Update Account.
$(document).on("vclick", "#page-detail #frm-update #btn-update", updateAccount);

function updateAccount(e) {
  e.preventDefault();

  var id = localStorage.getItem("currentPropertyId");
  var propertyName = $("#page-detail #frm-update #propertyName").val();
  var propertyAddress = $("#page-detail #frm-update #propertyName").val();
  var propertyType = $("#page-detail #frm-update #propertyType").val();
  var bedroom = $("#page-detail #frm-update #bedroom").val();
  var date = $("#page-detail #frm-update #date").val();
  var monthlyRentPrice = $("#page-detail #frm-update #monthlyRentPrice").val();
  var furnitureType = $("#page-detail #frm-update #furnitureType").val();
  var notes = $("#page-detail #frm-update #notes").val();
  var reporterName = $("#page-detail #frm-update #reporterName").val();

  db.transaction(function (tx) {
    var query =
      "UPDATE Property SET propertyName = ?, propertyAddress = ?, propertyType = ?, bedroom = ?, date = ?, monthlyRentPrice = ?, furnitureType = ?, notes = ?, reporterName = ? WHERE Id = ?";
    tx.executeSql(
      query,
      [
        propertyName,
        propertyAddress,
        propertyType,
        bedroom,
        date,
        monthlyRentPrice,
        furnitureType,
        notes,
        reporterName,
        id,
      ],
      transactionSuccess,
      transactionError
    );

    function transactionSuccess(tx, result) {
      $("#page-detail #propertyName").val(propertyName);
      $("#page-detail #propertyAddress").val(propertyAddress);
      $("#page-detail #propertyType").val(propertyType);
      $("#page-detail #bedroom").val(bedroom);
      $("#page-detail #date").val(date);
      $("#page-detail #monthlyRentPrice").val(monthlyRentPrice);
      $("#page-detail #furnitureType").val(furnitureType);
      $("#page-detail #notes").val(notes);
      $("#page-detail #reporterName").val(reporterName);

      $.mobile.navigate("#page-detail", { transition: "none" });
    }
  });
}

// Delete Account.
$(document).on("submit", "#page-detail #frm-delete", deleteAccount);
$(document).on(
  "keyup",
  "#page-detail #frm-delete #txt-delete",
  confirmDeleteAccount
);

function confirmDeleteAccount() {
  var text = $("#page-detail #frm-delete #txt-delete").val();

  if (text == "confirm delete") {
    $("#page-detail #frm-delete #btn-delete").removeClass("ui-disabled");
  } else {
    $("#page-detail #frm-delete #btn-delete").addClass("ui-disabled");
  }
}

function deleteAccount(e) {
  e.preventDefault();

  var id = localStorage.getItem("currentPropertyId");

  db.transaction(function (tx) {
    var query = "DELETE FROM Property WHERE Id = ?";
    tx.executeSql(query, [id], transactionSuccess, transactionError);

    function transactionSuccess(tx, result) {
      log(`Delete property '${id}' successfully.`);

      $("#page-detail #frm-delete").trigger("reset");

      $.mobile.navigate("#page-list", { transition: "none" });
    }
  });
}

// Update Account.
$(document).on("vclick", "#page-detail #frm-update #btn-update", updateAccount);

// Add Comment.
$(document).on("submit", "#page-detail #frm-comment", addComment);

function addComment(e) {
  e.preventDefault();

  var accountId = localStorage.getItem("currentAccountId");
  var comment = $("#page-detail #frm-comment #txt-comment").val();
  var dateTime = new Date();

  db.transaction(function (tx) {
    var query =
      "INSERT INTO Comment (AccountId, Comment, Datetime) VALUES (?, ?, ?)";
    tx.executeSql(
      query,
      [accountId, comment, dateTime],
      transactionSuccess,
      transactionError
    );

    function transactionSuccess(tx, result) {
      log(`Add new comment to account '${accountId}' successfully.`);

      $("#page-detail #frm-comment").trigger("reset");

      showComment();
    }
  });
}

// Show Comment.
function showComment() {
  var accountId = localStorage.getItem("currentAccountId");

  db.transaction(function (tx) {
    var query = "SELECT * FROM Comment WHERE AccountId = ?";
    tx.executeSql(query, [accountId], transactionSuccess, transactionError);

    function transactionSuccess(tx, result) {
      log(`Get list of comments successfully.`);

      // Prepare the list of comments.
      var listComment = "";
      for (let comment of result.rows) {
        listComment += `<div class = 'list'>
                                    <small>${comment.Datetime}</small>
                                    <h3>${comment.Comment}</h3>
                                </div>`;
      }

      // Add list to UI.
      $("#list-comment").empty().append(listComment);

      log(`Show list of comments successfully.`);
    }
  });
}

// Search.
$(document).on("submit", "#page-search #frm-search", search);

function search(e) {
  e.preventDefault();

  var propertyName = $("#page-search #frm-search #propertyName").val();
  var propertyType = $("#page-search #frm-search #propertyType").val();

  db.transaction(function (tx) {
    var query = `SELECT Id, propertyName, propertyType FROM Property WHERE`;

    if (propertyName) {
      query += ` propertyName LIKE "%${propertyName}%"   AND`;
    }

    if (propertyType) {
      query += ` propertyType LIKE ${propertyType}   AND`;
    }

    query = query.substring(0, query.length - 6);

    tx.executeSql(query, [], transactionSuccess, transactionError);

    function transactionSuccess(tx, result) {
      log(`Get list of properties successfully.`);

      // Prepare the list of accounts.
      var listProperty = `<ul id='list-account' data-role='listview' class='ui-nodisc-icon ui-alt-icon'>`;
      for (let property of result.rows) {
        listProperty += `<li><a data-details='{"Id" : ${property.Id}}'>
                                    <img src='img/boyscout_logo.jpg'>
                                    <h3>Property name: ${property.propertyName}</h3>
                                    <p>Property type: ${property.propertyType}</p>
                                </a></li>`;
      }
      listProperty += `</ul>`;

      // Add list to UI.
      $("#page-search #list-account")
        .empty()
        .append(listProperty)
        .listview("refresh")
        .trigger("create");

      log(`Show list of accounts successfully.`);
    }
  });
}
